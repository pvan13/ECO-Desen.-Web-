function atividadesMarajo(){
    window.location = "marajó.html"
}

function atividadesAmazonia(){
    window.location = "parque.html"
}

function atividadesCombu(){
    window.location = "combu.html"
}