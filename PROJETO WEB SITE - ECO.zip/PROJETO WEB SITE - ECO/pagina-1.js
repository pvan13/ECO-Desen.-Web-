function saibaMais(){
    window.location = "pagina-2.html"
}